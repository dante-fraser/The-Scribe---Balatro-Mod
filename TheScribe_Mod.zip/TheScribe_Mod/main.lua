SMODS.Atlas{
    key = "scribe_atlas",
    path = "scribe.png",
    px = 71,
    py = 95
}

SMODS.Tarot{
    key = "scribe",
    loc_txt = {
        name = "Scribe",
        text = {
            "Transfer all Enhancements,",
            "Editions, and Seals",
            "from right to left card"
        }
    },
    atlas = "scribe_atlas",
    pos = {x = 0, y = 0},
    cost = 3,
	
	 in_pool = function(self)
        return true
    end,

    can_use = function(self, card)
        return G.hand and G.hand.highlighted and #G.hand.highlighted == 2
    end,

    use = function(self, card, area, copier)
        local selected = G.hand.highlighted
        if #selected ~= 2 then return end

        table.sort(selected, function(a, b)
            return a.T.x < b.T.x
        end)

        local left = selected[1]
        local right = selected[2]

        if right.config.center 
		and right.config.center ~= G.P_CENTERS.c_base then
            left:set_ability(right.config.center)
            right:set_ability(G.P_CENTERS.c_base)
        end

        if right.edition then
            left:set_edition(right.edition, true)
            right:set_edition(nil, true)
        end

        if right.seal then
            left:set_seal(right.seal, true)
            right:set_seal(nil, true)
        end
    end
}