SMODS.Atlas{ 
    key = "scribe_atlas",
    path = "scribe.png",
    px = 71,
    py = 95
}

SMODS.Tarot{
    key = "scribe",
    loc_txt = {
        name = "Scribe",
        text = {
            "Transfer all Enhancements,",
            "Editions, and Seals",
            "from right to left card"
        }
    },
    atlas = "scribe_atlas",
    pos = {x = 0, y = 0},
    cost = 3,
	
	 in_pool = function(self)
        return true
    end,

    can_use = function(self, card)
        return G.hand and G.hand.highlighted and #G.hand.highlighted == 2
    end,

    use = function(self, card, area, copier)
        local selected = G.hand.highlighted
        if #selected ~= 2 then return end

        table.sort(selected, function(a, b)
            return a.T.x < b.T.x
        end)

        local left = selected[1]
        local right = selected[2]

        if right.config.center 
		and right.config.center ~= G.P_CENTERS.c_base then
            left:set_ability(right.config.center)
            right:set_ability(G.P_CENTERS.c_base)
        end

        if right.edition then
            left:set_edition(right.edition, true)
            right:set_edition(nil, true)
        end

        if right.seal then
            left:set_seal(right.seal, true)
            right:set_seal(nil, true)
        end
		
		if card.juice_up then pcall(function() card:juice_up(0.3, 0.5) end) end
		if left.juice_up then pcall(function() left:juice_up(0.3, 0.5) end) end
		if right.juice_up then pcall(function() right:juice_up(0.3, 0.5) end) end
    end
}


-- The Altar card
SMODS.Atlas{ 
    key = "altar_atlas",
    path = "altar.png",
    px = 71,
    py = 95
}

SMODS.Tarot{
    key = "altar",
    cost = 3,
    atlas = "altar_atlas",
    pos = { x = 0, y = 0 },

    loc_txt = {
        name = "Altar",
        text = {
            "Remove all Enhancements,",
            "Editions, and Seals",
            "from a card, gain {C:money}$5{} each"
        }
    },

    can_use = function(self, card)
    local hand = G.hand
    if not hand or not hand.highlighted or #hand.highlighted ~= 1 then
        return false
    end

    local c = hand.highlighted[1]

    return (
        c.config.center ~= G.P_CENTERS.c_base
        or c.edition
        or c.seal
    )
end,

    use = function(self, card, area, copier)
        local hand = G.hand
        if not hand or not hand.cards then return end

        G.E_MANAGER:add_event(Event({
            trigger = "after",
            delay = 0.2,
            func = function()
                local target = hand.highlighted[1]
                if not target then return true end

                local removed = 0

                -- remove enhancement
                if target.config.center ~= G.P_CENTERS.c_base then
                    target:set_ability(G.P_CENTERS.c_base)
                    removed = removed + 1
                end

                -- remove edition
                if target.edition then
                    target:set_edition(nil, true)
                    removed = removed + 1
                end

                -- remove seal
                if target.seal then
                    target:set_seal(nil, true)
                    removed = removed + 1
                end

                if removed > 0 then
                    ease_dollars(5 * removed)
                end

                if card.juice_up then pcall(function() card:juice_up(0.3, 0.5) end) end
                if target.juice_up then pcall(function() target:juice_up(0.3, 0.5) end) end

                if card.start_dissolve then
                    pcall(function() card:start_dissolve() end)
                end

                return true
            end
        }))
    end,
}